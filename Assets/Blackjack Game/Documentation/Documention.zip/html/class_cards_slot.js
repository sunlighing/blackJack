var class_cards_slot =
[
    [ "AddCard", "class_cards_slot.html#aae64a32b1b6a334ff789e52191b1d334", null ],
    [ "FlipAll", "class_cards_slot.html#a8f8f0c378cf2731c30d789cebaeaddf9", null ],
    [ "RemoveAll", "class_cards_slot.html#a363df13e0807f7a4b609bedc0b919308", null ],
    [ "Point", "class_cards_slot.html#a347967fc6e9e66fae4bf6106498363fc", null ]
];