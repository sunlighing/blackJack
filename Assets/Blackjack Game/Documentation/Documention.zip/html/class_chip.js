var class_chip =
[
    [ "Clear", "class_chip.html#aa83665930a364060896eff3d9e562520", null ],
    [ "FlyToBanker", "class_chip.html#aef10a0d470fcb18c65fbe47b5b3b76b2", null ],
    [ "FlyToPlayer", "class_chip.html#aebd327c5c750954a082fd3d759650716", null ],
    [ "FlyToSide", "class_chip.html#a8dc9f82c7814c5e8013f4a06b91f6647", null ],
    [ "ResetPosition", "class_chip.html#a9767eb19c38f917dcfbea54bf01321bc", null ],
    [ "ShowChips", "class_chip.html#a7d1bbcfcc714f85f26ebb2f29bd1f8b0", null ]
];