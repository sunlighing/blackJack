var annotated_dup =
[
    [ "Card", "class_card.html", "class_card" ],
    [ "CardsSlot", "class_cards_slot.html", "class_cards_slot" ],
    [ "Chip", "class_chip.html", "class_chip" ],
    [ "Dealer", "class_dealer.html", "class_dealer" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "RefSingleton", "class_ref_singleton.html", "class_ref_singleton" ],
    [ "SoundManager", "class_sound_manager.html", null ],
    [ "UIButtonsPanel", "class_u_i_buttons_panel.html", "class_u_i_buttons_panel" ],
    [ "UIChipsPanel", "class_u_i_chips_panel.html", "class_u_i_chips_panel" ],
    [ "UIMain", "class_u_i_main.html", "class_u_i_main" ]
];