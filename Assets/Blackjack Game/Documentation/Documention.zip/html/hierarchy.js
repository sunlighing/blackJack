var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "Card", "class_card.html", null ],
      [ "CardsSlot", "class_cards_slot.html", null ],
      [ "Dealer", "class_dealer.html", null ],
      [ "RefSingleton< T >", "class_ref_singleton.html", null ],
      [ "UIButtonsPanel", "class_u_i_buttons_panel.html", null ],
      [ "UIChipsPanel", "class_u_i_chips_panel.html", null ],
      [ "UIMain", "class_u_i_main.html", null ]
    ] ],
    [ "RefSingleton< Chip >", "class_ref_singleton.html", [
      [ "Chip", "class_chip.html", null ]
    ] ],
    [ "RefSingleton< Game >", "class_ref_singleton.html", [
      [ "Game", "class_game.html", null ]
    ] ],
    [ "RefSingleton< SoundManager >", "class_ref_singleton.html", [
      [ "SoundManager", "class_sound_manager.html", null ]
    ] ]
];