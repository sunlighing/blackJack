var class_u_i_buttons_panel =
[
    [ "HideButtons", "class_u_i_buttons_panel.html#a01782ae032aba7fc0369c412d8788f20", null ],
    [ "ShowButtons", "class_u_i_buttons_panel.html#a27cfc39cd8a56deec97e1d6c8f6520bd", null ]
];