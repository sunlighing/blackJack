var class_dealer =
[
    [ "Deal", "class_dealer.html#a0f9952d629769515ceba7cc0e5f693c1", null ]
];