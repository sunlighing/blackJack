var searchData=
[
  ['deal',['Deal',['../class_dealer.html#a0f9952d629769515ceba7cc0e5f693c1',1,'Dealer']]],
  ['dealer',['Dealer',['../class_dealer.html',1,'']]],
  ['destorysingleton',['DestorySingleton',['../class_ref_singleton.html#af2d836257e0a7b19b33ab77391e1b623',1,'RefSingleton']]],
  ['double',['Double',['../class_game.html#a393784565706ab809a777c5b4f63df18',1,'Game']]]
];
