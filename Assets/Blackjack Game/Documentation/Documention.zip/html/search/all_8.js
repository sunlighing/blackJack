var searchData=
[
  ['point',['Point',['../class_cards_slot.html#a347967fc6e9e66fae4bf6106498363fc',1,'CardsSlot']]]
];
