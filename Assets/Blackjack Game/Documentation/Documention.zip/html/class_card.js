var class_card =
[
    [ "Flip", "class_card.html#a54accc029311e34c3d780959318046d1", null ]
];