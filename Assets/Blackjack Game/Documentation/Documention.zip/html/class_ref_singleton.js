var class_ref_singleton =
[
    [ "DestorySingleton", "class_ref_singleton.html#af2d836257e0a7b19b33ab77391e1b623", null ],
    [ "OnDestroy", "class_ref_singleton.html#a7ca05d701c8a441dd8a1a8ceafe15458", null ]
];